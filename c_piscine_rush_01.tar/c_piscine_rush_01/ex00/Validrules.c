
#include <stddef.h>


int** montaColDown(int regraColDown[4], int regraColup[4], int** matrix)
{  
    int i = 0;
    int idx = 3;
    while(i <= regraColDown[i])
    {
        if(regraColDown[i] == 4)// 2 ou 3
        { // colup1 - matix[linha][colunas]
            while (matrix[3][i])
            {
                matrix[3][i] = 1;
            }

            matrix[3][i] = 1;
            matrix[3][i] = 2;
            matrix[3][i] = 3;
            matrix[3][i] = 4;
            i++;
        }
        if(regraColDown[i] == 3)// colup2 - matix[linha][colunas]
        {
            matrix[3][i] = 2;
            matrix[3][i] = 3;
            matrix[3][i] = 4;
            // matrix[3][i] = 0;
            i++;
        }
        if(regraColDown[i] == 2)// colup3 - matix[linha][colunas]
        {
            if(matrix[3][1] == 0){
                matrix[3][1] = 1;
                i++;
            }
        }
        if(regraColDown[i] == 1)// colup4 - matix[linha][colunas]
        {
            if(matrix[3][0] == 4){
                i++;
            }else{
                //erro
            }
            // matrix[3][i] = 0;
            // matrix[3][i] = 0;
            // matrix[3][i] = 0;
        }
        i++;
    }

    return(matrix);}

int** montaColUp(int regra[])
{
    int i = 0;
    int **matrix = (int **)malloc(4 * sizeof(int *));
    while( i < 4) {
        matrix[i] = (int *)malloc(4 * sizeof(int));
        int j = 0;
        while ( j < 4) {
            matrix[i][j] = 0; // Inicialize a matriz para evitar valores não definidos
            j++;
        }
        i++;
    }
    i = 0;
    while(i <= regra[i])
    {
        if(regra[i] == 4)// 2 ou 3
        { // colup1 - matix[linha][colunas]
            matrix[0][i] = 1;
            matrix[1][i] = 2;
            matrix[2][i] = 3;
            matrix[3][i] = 4;
            i++;
        }
        if(regra[i] == 3)// colup2 - matix[linha][colunas]
        {
            matrix[0][i] = 2;
            matrix[1][i] = 3;
            matrix[2][i] = 4;
            matrix[3][i] = 0;
            i++;
        }
        if(regra[i] == 2)// colup3 - matix[linha][colunas]
        {
            matrix[0][i] = 3;
            matrix[1][i] = 4;
            matrix[2][i] = 0;
            matrix[3][i] = 0;
            i++;

        }
        if(regra[i] == 1)// colup4 - matix[linha][colunas]
        {
            matrix[0][i] = 4;
            matrix[1][i] = 0;
            matrix[2][i] = 0;
            matrix[3][i] = 0;
            i++;
        }
    }

    return(matrix);
}

void print_matix(int matrix[3][3])
{
    int row_count = 0;
    int line_count = 0;
    while(line_count < 3 )
    {
        printf("%d", matrix[line_count][0]);
        line_count++;
    }

}

void imprimirMatrix(int **matrix) {
    int i = 0;
    while ( i < 4) {
        int j = 0;
        while ( j < 4) {
            printf("%d ", matrix[i][j]);
            j++;
        }
        printf("\n");
        i++;
    }
}
int main(){
    int regraColUp[4] = {4, 3, 2, 1};
    int regraColDown[4] = {1, 2, 2, 2};
    int regraRowLeft[4] = {4, 3, 2, 1};
    int regraRowRigth[4] = {1, 2, 2, 1};

    //int **matrix = montaColDown(regraColDown, regraColUp, montaColUp(regraColUp));
    int **matrix = montaColUp(regraColUp);


    imprimirMatrix(matrix);
    int i = 0;
    while ( i < 4) {
        free(matrix[i]);
        i++;
    }
    free(matrix);
    return 0;
}
