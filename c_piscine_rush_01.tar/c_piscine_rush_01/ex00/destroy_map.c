/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   destroy_map.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cfelipe- <cfelipe-@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/27 00:30:04 by cfelipe-          #+#    #+#             */
/*   Updated: 2023/08/27 03:49:18 by cfelipe-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "game.h"

void	destroy_map(t_map map)
{
	int	i;

	i = 0;
	while (i < map.size)
	{
		free(map.grid[i]);
		i++;
	}
	free(map.grid);
}
