/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   create_map.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cfelipe- <cfelipe-@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/27 00:08:52 by cfelipe-          #+#    #+#             */
/*   Updated: 2023/08/27 15:42:10 by cfelipe-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "game.h"

t_map	create_map(int size)
{
	t_map	map;
	int		i;
	int		j;

	map.size = size;
	map.grid = (int **)malloc(size * sizeof(int *));
	i = 0;
	while (i < size)
	{
		map.grid[i] = (int *)malloc(size * sizeof(int *));
		j = 0;
		while (j < size)
		{
			map.grid[i][j] = 0;
			j++;
		}
		i++;
	}
	return (map);
}
