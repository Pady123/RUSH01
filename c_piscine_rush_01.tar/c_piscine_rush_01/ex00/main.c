/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cfelipe- <cfelipe-@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/27 02:30:21 by cfelipe-          #+#    #+#             */
/*   Updated: 2023/08/27 18:33:12 by cfelipe-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "game.h"

int	main(int argc, t_string argv[])
{
	t_map		map;
	t_string	clues;

	map = create_map(SIZE);
	clues = validate_args(argc, argv);
	if (clues && solve(map, parse_clues(clues)))
	{
		print_map(map);
	}
	else
	{
		ft_puts("Error");
	}
	destroy_map(map);
	return (0);
}
