/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validate_args.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cfelipe- <cfelipe-@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/27 14:39:32 by cfelipe-          #+#    #+#             */
/*   Updated: 2023/08/27 18:46:02 by cfelipe-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "utils.h"

bool	validate_argc(int argc);
bool	validate_strlen(t_string clues);
bool	validate_format(t_string clues);

t_string	validate_args(int argc, t_string argv[])
{
	char	*clues;

	if (!validate_argc(argc))
	{
		return (NULL);
	}
	clues = argv[1];
	if (!(validate_strlen(clues) && validate_format(clues)))
	{
		return (NULL);
	}
	return (clues);
}

bool	validate_argc(int argc)
{
	if (argc != ARG_COUNT)
	{
		return (false);
	}
	return (true);
}

bool	validate_strlen(t_string clues)
{
	if (ft_strlen(clues) != CLUE_COUNT)
	{
		return (false);
	}
	return (true);
}

bool	validate_format(t_string clues)
{
	int	i;

	i = 0;
	while (clues[i] != '\0')
	{
		if (i % 2 == 0)
		{
			if (!(clues[i] >= '1' && clues[i] <= (SIZE + '0')))
			{
				return (false);
			}
		}
		else
		{
			if (clues[i] != ' ')
			{
				return (false);
			}
		}
		i++;
	}
	return (true);
}
