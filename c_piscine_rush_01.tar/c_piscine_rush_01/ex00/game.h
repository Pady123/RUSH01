/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   game.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cfelipe- <cfelipe-@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/27 02:30:06 by cfelipe-          #+#    #+#             */
/*   Updated: 2023/08/27 16:29:41 by cfelipe-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GAME_H
# define GAME_H
# include "utils.h"

typedef struct s_map
{
	int	**grid;
	int	size;
}	t_map;

t_map	create_map(int size);
void	destroy_map(t_map map);
void	print_map(t_map map);
int		*parse_clues(t_string clues);
bool	solve(t_map map, int *parsed_clues);

#endif
